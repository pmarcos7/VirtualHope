# Arcaedion Multiplayer Base

Seja bem vindo a este projeto base! Abra a cena JogoMain para ver a jogabilidade padrão.

Siga o tutorial com atenção! Boa sorte!